import React from 'react';

export default function CoffeePortfolioWebsite() {
  const imageUrl = "/images/sample.png"; // placeholder image

  const services = [
    "Στρατηγική Social Media",
    "Δημιουργία Περιεχομένου (Reels, Posts, Stories, TikToks)",
    "Κείμενα & Copywriting",
    "Γραφιστικός Σχεδιασμός",
    "Πρόγραμμα Δημοσιεύσεων",
    "Διαχείριση Κοινότητας",
    "Hashtag & SEO Βελτιστοποίηση",
    "Μηνιαίες Αναφορές Analytics",
  ];

  const shopTypes = [
    { title: "Καφέ & Coffee Shops", why: "Εξαιρετικά οπτικό περιεχόμενο — ιδανικό για Reels, Stories και καθημερινές προωθήσεις.", how: "Προβολή μενού, latte art, behind-the-scenes, καθημερινές προσφορές και συνεργασίες με τοπικά brands για αύξηση επισκεψιμότητας." },
    { title: "Φούρνοι & Ζαχαροπλαστεία", why: "Το food content έχει υψηλή αλληλεπίδραση και μεγάλη δυναμική στην Ελλάδα.", how: "Συνταγές, time-lapse baking videos, παρουσίαση προϊόντων, εποχιακές προωθήσεις και stories για άμεση πώληση." },
    { title: "Κομμωτήρια & Barber Shops", why: "Τα before/after και τα μικρά tutorials είναι viral περιεχόμενο.", how: "Μεταμορφώσεις πελατών, παρουσίαση υπηρεσιών, εκπαιδευτικά snips και συνεργασίες με τοπικούς influencers." },
    { title: "Μπουτίκ & Καταστήματα Ρούχων", why: "Ιδανικά για lookbooks, UGC και προβολή νέων συλλογών.", how: "Photo shoots, styling videos, limited drops, stories με links και προώθηση e‑shop." },
    { title: "Γυμναστήρια & Yoga Studios", why: "Το fitness περιεχόμενο αυξάνει γρήγορα engagement και leads.", how: "Μικρά clips από μαθήματα, παρουσιάσεις προπονητών, testimonials μελών και προσφορές εισαγωγικών πακέτων." },
  ];

  return (
    <div className="min-h-screen bg-[#1b1a17] text-[#e8e0d7] px-6 py-12">
      <div className="max-w-5xl mx-auto bg-[#242320] shadow-xl rounded-2xl overflow-hidden">
        <header className="p-8 md:flex md:items-center md:justify-between">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold">Γιάννης Τσίκο</h1>
            <p className="mt-2 text-lg text-[#e8e0d7]/60">Social Media Manager — Ειδικός στη διαχείριση καφέ & τοπικών επιχειρήσεων</p>
          </div>
          <div className="mt-6 md:mt-0">
            <a href="#contact" className="inline-block px-5 py-3 bg-[#d4a373] text-white rounded-full shadow">Επικοινωνία</a>
          </div>
        </header>

        <section className="grid md:grid-cols-2 gap-6 p-8 border-[#3c2f2f]-t">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Υπηρεσίες</h2>
            <ul className="space-y-2">
              {services.map((s) => <li key={s} className="p-3 rounded-lg bg-[#1b1a17] border-[#3c2f2f]">{s}</li>)}
            </ul>
          </div>
          <div>
            <h2 className="text-2xl font-semibold mb-4">Γιατί να συνεργαστούμε</h2>
            <p className="text-[#e8e0d7]/80">Διαχειρίζομαι πολλαπλές επιχειρήσεις με δημιουργικότητα, συνέπεια και στρατηγική σκέψη...</p>
          </div>
        </section>

        <section className="p-8 border-[#3c2f2f]-t">
          <h2 className="text-2xl font-semibold mb-4">Δείγματα Περιεχομένου</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map((i) => <img key={i} src={imageUrl} alt={`sample ${i}`} className="w-full h-40 object-cover rounded-lg shadow" />)}
          </div>
        </section>

        <section className="p-8 border-[#3c2f2f]-t">
          <h2 className="text-2xl font-semibold mb-4">Επιχειρήσεις που αναλαμβάνω</h2>
          <div className="space-y-4">
            {shopTypes.map((s) => (
              <div key={s.title} className="p-4 border-[#3c2f2f] rounded-lg bg-[#1b1a17]">
                <h3 className="font-semibold">{s.title}</h3>
                <p className="text-sm text-[#e8e0d7]/60 mt-1"><strong>Γιατί:</strong> {s.why}</p>
                <p className="text-sm text-[#e8e0d7]/60 mt-1"><strong>Πώς βοηθάω:</strong> {s.how}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="p-8 border-[#3c2f2f]-t">
          <h2 className="text-2xl font-semibold mb-4">Επικοινωνία</h2>
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <div className="p-4 border-[#3c2f2f] rounded-lg">
              <h4 className="font-semibold">Email</h4>
              <p className="text-[#e8e0d7]/60">giannistsiko12345@gmail.com</p>
            </div>
          </div>
        </section>

        <footer className="p-6 text-center text-sm text-gray-500">© {new Date().getFullYear()} Γιάννης Τσίκο</footer>
      </div>
    </div>
  );
}