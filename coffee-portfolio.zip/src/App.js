import React from 'react';
import CoffeePortfolioWebsite from './components/CoffeePortfolioWebsite';

function App() {
  return <CoffeePortfolioWebsite />;
}

export default App;